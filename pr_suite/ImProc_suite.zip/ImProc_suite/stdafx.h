// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include <stdio.h>

#include <cv.h>
#include <cxcore.h>
#include <assert.h>
#include <highgui.h>
//Our external include files

#include "Image.h"
#include "ImageProcessor.h"
#include <stdlib.h>

#include <math.h>
#include "defines.h"





