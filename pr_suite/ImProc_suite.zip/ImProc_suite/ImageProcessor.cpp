#include "stdafx.h"



/*
*Applies a binary threshold 
*@param ptrInput, input image
*@param threshValue, if the pixel value is higher than threshValue, a 255 (white) is set, 0 is set otherwise
*@return Image, thresholded image
*/
Image* applyThresholdBinary(Image* ptrInput, double threshValue){
	Image* ptrOutput = initImage(ptrInput->width, ptrInput->height, 1);
	int i;
	for(i = 0;i < ptrOutput->totalLength; ++i){
		double value = ptrInput->ptrImageData[i];
		if(value > threshValue){
			ptrOutput->ptrImageData[i] = MAX_GS;
		}
		else{
			ptrOutput->ptrImageData[i] = MIN_GS;
		}
	}
	return ptrOutput;
}

/*
*Applies a local mean filter to the image
*@param ptrImage, input image 
*@param apertureSize, window size, must be uneven
*/
Image* filterMean(Image* ptrInput, int apertureSize){	
	Image *ptrMeanMask = generateMeanMask(apertureSize);
	Image* ptrOutput = filter2D(ptrInput, ptrMeanMask);
	deleteImage(ptrMeanMask);
	return ptrOutput;
}

/*
*Applies a variance filter to the image
*@param ptrImage, input image 
*@param apertureSize, window size, must be uneven
*/
Image* filterVariance(Image* ptrInput, int apertureSize){
	Image* ptrVarianceMask = initMask(apertureSize, apertureSize, 1);
	int x, y;	
	double *ptrSum = (double*)malloc(sizeof(double));
	Image* ptrOutput = initImage(ptrInput->width, ptrInput->height, 1);	
	for(x = 0; x < ptrInput->width; ++x){
		for(y = 0; y < ptrInput->height; ++y){	
			Image* ptrTemp = createMaskedSubImage(ptrVarianceMask, ptrInput, x, y, ptrSum, true);
			double variance = getVariancePixel(ptrTemp);
			setPV(ptrOutput, x, y, (unsigned int)variance, 0);
			deleteImage(ptrTemp);
		}
	}
	delete ptrSum;
	return ptrOutput;
}

/*
*Applies a Prewitt filter to calculate the gradient filter
*@param ptrImage, input image 
*@param apertureSize, window size, must be uneven
*/
Image* filterPrewitt(Image* ptrInput, Gradient gradient, int apertureSize){
	Image* ptrPrewittMaskX = generatePrewittXMask(apertureSize);
	Image* ptrPrewittMaskY = trasposeImage(ptrPrewittMaskX);
	Image* ptrOutput;
	
	if(gradient == GRAD_X){
		ptrOutput = filter2D(ptrInput, ptrPrewittMaskX);
	}
	if(gradient == GRAD_Y){
		ptrOutput = filter2D(ptrInput, ptrPrewittMaskY);
	}
	if(gradient == GRAD_X_Y){
		Image* ptrX = filter2D(ptrInput, ptrPrewittMaskX);
		Image* ptrY = filter2D(ptrInput, ptrPrewittMaskY);
		ptrOutput = addImages(ptrX, ptrY);
	}
	Image* ptrOutputInv = invertImageValues(ptrOutput, MAX_GS);
	deleteImage(ptrPrewittMaskY);
	deleteImage(ptrPrewittMaskX);
	deleteImage(ptrOutput);
	return ptrOutputInv;
}
/*
*Applies a Sobel filter to calculate the gradient filter
*@param ptrImage, input image 
*@param apertureSize, window size, must be uneven
*/
Image* filterSobel(Image* ptrInput, Gradient gradient){
	Image* ptrSobelMaskX = generateSobelXMask();
	Image* ptrSobelMaskY = trasposeImage(ptrSobelMaskX);
	Image* ptrOutput;
	
	if(gradient == GRAD_X){
		ptrOutput = filter2D(ptrInput, ptrSobelMaskX);
	}
	if(gradient == GRAD_Y){
		ptrOutput = filter2D(ptrInput, ptrSobelMaskY);
	}
	if(gradient == GRAD_X_Y){
		Image* ptrX = filter2D(ptrInput, ptrSobelMaskX);
		Image* ptrY = filter2D(ptrInput, ptrSobelMaskY);
		ptrOutput = addImages(ptrX, ptrY);
	}
	Image* ptrOutputInv = invertImageValues(ptrOutput, MAX_GS);
	deleteImage(ptrSobelMaskY);
	deleteImage(ptrSobelMaskX);
	deleteImage(ptrOutput);
	return ptrOutputInv;

}

/*
*Creates a new image with the same size of the mask, copying the surrounding pixels of Xo and Yo
*Calculates the image with the received mask, applying a dot product.
*It also calculates the ponderated the local value of the convolution using the mask and its maskFactor
*Desinged for internal use 
*@param ptrMask, mask to use
*@param ptrInput, Input image
*@param Xo, X coordinate position of the ptrInput pixel 
*@param Yo, Y coordinate position of the ptrInput pixel 
*@param ptrSum, result of multiplying the pixel of the mask with the pixel of the image and the maskFactor
*@return Image, masked image
*/
Image* createMaskedSubImage(Image* ptrMask, Image* ptrInput, int Xo, int Yo, double *ptrSum, bool returnMasked){
	Image* ptrMaskedSubImage = NULL;
	int Xi, Yi, Xm, Ym;
	if(returnMasked)
		ptrMaskedSubImage = initImage(ptrMask->width, ptrMask->height, 1);
	double sum = 0;
	//Origin on Image of the local convolution
	//Remember that the origin goes on the inferior left side of the windowed image
	Xi = Xo - ((ptrMask->width - 1) / 2);			
	for(Xm = 0; Xm < ptrMask->width; ++Xm){
		Yi = Yo - ((ptrMask->height - 1) / 2);
		for(Ym = 0; Ym < ptrMask->height; ++Ym){					
			if(isValid(Xi, Yi, ptrInput)){
				double mv = getPV(ptrMask, Xm, Ym);
				double pv = (double)getPV(ptrInput, Xi, Yi);
				double val = mv * pv;		
				sum += val;
				if(returnMasked)
					setPV(ptrMaskedSubImage, Xm, Ym, (unsigned char)val, 0);
			}
			Yi++;
		}
		Xi++;
	}	
	//If the value is negative, we take the abs value
	if(sum < 0){
		sum = sum * -1;
	}
	*ptrSum = sum;
	return ptrMaskedSubImage;
}
/*
*Convolves the input image with the mask
*@param ptrInput, input image
*@param ptrMask, mask
*/
Image* filter2D(Image* ptrInput, Image* ptrMask){
	int x, y;	
	double *ptrSum = (double*)malloc(sizeof(double));
	Image* ptrOutput = initImage(ptrInput->width, ptrInput->height, 1 );	
	for(x = 0; x < ptrInput->width; ++x){
		for(y = 0; y < ptrInput->height; ++y){	
			createMaskedSubImage(ptrMask, ptrInput, x, y, ptrSum, false);
			setPV(ptrOutput, x, y, *ptrSum, 0);
		}
	}
	delete ptrSum;
	return ptrOutput;
}

/*
*Calculates the image histogram
*@param image, input image must be gray scaled
*@return ArrayInt
*/
ArrayInt* calculateImageHistogram(Image* ptrImageGS){
	assert(ptrImageGS->dimension == 1);
	int i;
	ArrayInt* ptrHistogram = initArrayInt(NUM_GRAY_VALUES);
	
	for(i = 0; i < ptrImageGS->totalLength; ++i){
		int value = (int)ptrImageGS->ptrImageData[i];
        if(value > 255){
            value = 255;
        }
        if(value < 0){
            value = 0;
        }
		ptrHistogram->ptrArray[value]++;
	}
	return ptrHistogram;
}

/*
*Calculates the image histogram
*@param image, input image must be gray scaled
*@return ArrayInt
*/
int* calculateImageHistogramInt(Image* ptrImageGS){
    assert(ptrImageGS->dimension == 1);
    int i;
    int* ptrHistogram = new int[NUM_GRAY_VALUES];
    for(i = 0; i < NUM_GRAY_VALUES; ++i){
        ptrHistogram[i] = 0;
    }
    for(i = 0; i < ptrImageGS->totalLength; ++i){
        int value = (int)ptrImageGS->ptrImageData[i];
        if(value > 255){
            value = 255;
        }
        if(value < 0){
            value = 0;
        }
        ptrHistogram[value]++;
    }
    return ptrHistogram;
}
/*
*Calculates the density function
*@param image, input image must be gray scaled
*@return ArrayDouble
*/
ArrayDouble* calculateImageDensityFunction(Image* ptrImageGS){
	//Only gray scaled images are valid
	assert(ptrImageGS->dimension == 1);
	ArrayInt* ptrHistogram = calculateImageHistogram(ptrImageGS);

    ArrayDouble* ptrDensityFunc = initArrayDouble(NUM_GRAY_VALUES);

	int i;	
	for(i = 0; i < NUM_GRAY_VALUES; ++i){
		ptrDensityFunc->ptrArray[i] = ((double)ptrHistogram->ptrArray[i]/(double)ptrImageGS->totalLength)*100;	
	}
	return ptrDensityFunc;
}
/*
Upsizes the received image by a given factor
the algorithm uses bilineal interpolation
@param Image*, pointer to the gray scaled image
@param factor, resize factor
@return Image*, pointer to the resized image
*/
Image* upsize(Image* ptrOriginal, int factor){
	//must be a gray scale image
	assert(factor > 0 && ptrOriginal->dimension == 1);
	Image* ptrResized = initImage(ptrOriginal->width * factor, ptrOriginal->height * factor, 1);
	//width columns, height rows
	//Resized image counters
	int Rx, Ry;	
	//current local Origin on Resized Image
	int LORx = 0;
	int LORy = 0;
	//current local Origin on the Original image
	int LOOx = 0;
	int LOOy = 0;
	unsigned char Y1, Y2, Y3, Y4;
	double a, b, c, d;
	//Origin inferior left of the image
	for(Ry = 0; Ry < ptrResized->height; ++Ry){
		for(Rx = 0; Rx < ptrResized->width; ++Rx){						
			if(Rx == 0 || Rx % factor == 0){
				LORx = Rx;
			}
			//In this pixel, the original value must be copied		
			if( (Ry == 0 || Ry % factor == 0)&& (Rx == 0 || Rx % factor == 0)){									
				setPV(ptrResized, Rx, Ry, getPV(ptrOriginal, (int)((double)Rx / (double)factor), (int)((double)Ry / (double)factor)), 0);									
			}
			//in this case, an interpolation of the pixel is necessary 
			else{
				//Formula variables initialiazed
				Y1 = 0;
				Y2 = 0;
				Y3 = 0;
				Y4 = 0;
				LOOx = (int)((double)LORx / (double)factor);
				LOOy = (int)((double)LORy / (double)factor);				
				//Formula taken from the course notes, Bilineal interpolation
				Y1 = (unsigned char)getPV(ptrOriginal, LOOx, LOOy);
				//The value in the original image might be out range, anyway is null in the formula
				if(LOOx + 1 < ptrOriginal-> width)
					Y2 = (unsigned char)getPV(ptrOriginal, LOOx + 1, LOOy);
				if(LOOx + 1 < ptrOriginal-> width && LOOy + 1 < ptrOriginal->height)
					Y3 = (unsigned char)getPV(ptrOriginal, LOOx + 1, LOOy + 1);
				if(LOOy + 1 < ptrOriginal-> height)
					Y4 = (unsigned char)getPV(ptrOriginal, LOOx, LOOy + 1);
				a = (double)(Y2 - Y1);
				b = (double)(Y4 - Y1);
				c = (double)(Y1 + Y3 - Y2 - Y4);
				d = (double)Y1;
				//normalized delta
				double deltaX = ((double)(Rx - LORx))/(double)factor;
				double deltaY = ((double)(Ry - LORy))/(double)factor;
				double dYe = (a * deltaX + b * deltaY + c * deltaY * deltaX + d);				
				/*if(dYe <= 0 || dYe > MAX_GS){
					printf("VALOR INCORRECTO\n");
				}*/
				setPV(ptrResized, Rx, Ry, (unsigned char)dYe, 0);
			}
		}
		if(Ry == 0 || Ry % factor == 0 ){			
			//The Local Origin of the resized image is updated
			LORy = Ry;
			//The original image column counter is reseted
			LORx = 0;			
		}		
	}
	return ptrResized;
}



/*
*Generates the mask (matrix of 1's) used on the local mean calculation
*@param apertureSize, window size, must be uneven
*@return Image, mean mask
*/
Image* generateMeanMask(int apertureSize){
	int totalElements = apertureSize * apertureSize;
	Image* ptrMask = initMask(apertureSize, apertureSize, 1.0 / (double)totalElements);	
	return ptrMask;
}


/*
*Generates the sobel mask to approximate the X gradient
*@param apertureSize, window size, must be uneven
*@return Image, sobel mask
*/
Image* generateSobelXMask(){	
	Image* ptrMask = initMask(3, 3, 1);
	int i;
	double temp[9] = {1.0 / 8.0, 0, -1.0 / 8.0, 2.0 /8.0, 0, -2.0 / 8.0, 1.0 / 8.0, 0, -1.0 / 8.0};
	for(i = 0; i < ptrMask->totalLength; ++i){
		ptrMask->ptrImageData[i] = temp[i];
	}
	return ptrMask;
}


/*
*Generates the prewitt mask to approximate the X gradient
*@param apertureSize, window size, must be uneven
*@return Image, mean mask
*/
Image* generatePrewittXMask(int apertureSize){
	int totalElements = apertureSize * apertureSize;
	Image* ptrMask = initMask(apertureSize, apertureSize, 1);
	int x, y;
	for(x = 0; x < ptrMask->width; ++x){
		for(y = 0; y < ptrMask->height; ++y){
			//if its a border, the prewit mask has a 1
			setPV(ptrMask, x, y, 0, 0);
			if(y == 0){
				setPV(ptrMask, x, y, 1.0 / 6.0, 0);
			}//otherwise a 0
			if(y == ptrMask->width - 1){
				setPV(ptrMask, x, y, -1.0 / 6.0, 0);
			}
		}
	}
	return ptrMask;
}
