#include "openimprolib.h"

OpenImProLib::OpenImProLib(){
}
