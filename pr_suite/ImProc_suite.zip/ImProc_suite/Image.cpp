#include "stdafx.h"
/*
*Shows image values on the console
*@param ptrImage, image to show
*/
void printImage(Image* ptrImage){
	int i, j;
	double result = 0;
	for(i = 0; i < ptrImage->width; ++i){
		for(j = 0; j < ptrImage->height; ++j){
			printf(" %f ", getPV(ptrImage, i, j, 0));
		}
		printf("\n");
	}
}
/*
Loads an Image struct from file
@param ptrPath, absolute or relative path
@return ptrImage, pointer to the RGB image
*/
Image* loadImageC(char* ptrPath){
	IplImage* ptrCvImage = cvLoadImage(ptrPath);	
	Image* ptrImage = convertToImage(ptrCvImage);	
	return ptrImage;
} 
/*
Calculates the average pixel value of a given Gray Scale Image
@param Image*, pointer to the gray scaled image
*/
double getMeanPixel(Image* ptrImage){
	//Must be a gray scale image
	assert(ptrImage->dimension == 1);		
	int i, j;
	double result = 0;
	for(i = 0; i < ptrImage->width; ++i){
		for(j = 0; j < ptrImage->height; ++j){
			result += (double)getPV(ptrImage, i, j);
		}
	}
	result = result / (double)ptrImage->totalLength;
	return result;
}

/*
Calculates the average pixel value of a given Gray Scale Image
@param Image*, pointer to the gray scaled image
*/
double getSquaredMeanPixel(Image* ptrImage){
	//Must be a gray scale image
	assert(ptrImage->dimension == 1);		
	int i, j;
	double result = 0;
	for(i = 0; i < ptrImage->width; ++i){
		for(j = 0; j < ptrImage->height; ++j){
			result += (double)getPV(ptrImage, i, j) * (double)getPV(ptrImage, i, j);
		}
	}
	result = result / (double)ptrImage->totalLength;
	return result;
}

/*
Calculates the variance pixel value of a given Gray Scale Image
@param Image*, pointer to the gray scaled image
*/
double getVariancePixel(Image* ptrImage){
	//Must be a gray scale image
	assert(ptrImage->dimension == 1);		
	double meanPixel = getMeanPixel(ptrImage);
	
	double squaredMeanPixel = getSquaredMeanPixel(ptrImage);
	//Using simplified formula variance = E[x^2] - E[x]^2
	double result = squaredMeanPixel - meanPixel * meanPixel;
	/*
	double factor = (double)1/((double)(ptrImage->totalLength) - 1.0);
	int i, j;
	double result = 0;
	for(i = 0; i < ptrImage->width; ++i){
		for(j = 0; j < ptrImage->height; ++j){
			double pv = (double)getPV(ptrImage, i, j); 
			result += (pv - meanPixel) * (pv - meanPixel);
		}
	}
	result = result * factor;*/
	return result;
}

/*
Converts an IplImage struct Image (OpenCV), to the Image struct
@param ptrCVImage, pointer to the OpenCV image
@return Image*, pointer to the new RGB image
*/
Image* convertToImage(IplImage* ptrCvImage){
	int i, j, k;
	Image* ptrImage = initImage(ptrCvImage->width, ptrCvImage->height, ptrCvImage->nChannels);
	cvCvtColor(ptrCvImage , ptrCvImage, CV_BGR2RGB); 	
	for (i = 0;i < ptrImage->height; i++) {				
		for(j = 0; j < ptrImage->width; j++) {
			for( k = 0; k < ptrImage->dimension; ++k){								
				setPV(ptrImage, j, i, (int)getPV(ptrCvImage, j, i, k), k);
			}
		}
	}
	return ptrImage;
}
/*
Converts an Image struct to IplImage struct Image (OpenCV)
@param ptrCVImage, pointer to the OpenCV image
@return Image*, pointer to the new  image
*/
IplImage* convertToCvImage(Image* ptrImage){
	int i, j, k;
	CvSize imageSize = cvSize(ptrImage->width, ptrImage->height);
	IplImage *ptrCvImage = cvCreateImage(imageSize , IPL_DEPTH_8U, ptrImage->dimension); 
	for (i = 0;i < ptrImage->height; i++) {		
		for(j = 0; j < ptrImage->width; j++) {
			for( k = 0; k < ptrImage->dimension; ++k){				
				double value = getPV(ptrImage, j, i, k);		
				if(value > 255){
					value = 255;
				}
				if(value < 0){
					value = 0;
				}
				setPV(ptrCvImage, j, i, (unsigned char)value, k );
			}
		}		
	}
	if(ptrImage->dimension == 3)
		cvCvtColor(ptrCvImage , ptrCvImage, CV_RGB2BGR);
	return ptrCvImage;
}

/*
Converts an Image struct to a Gray Scale struct Image (OpenCV), using the YUV format
@param Image*, pointer to the new  image
@return ptrImageGS, pointer to the Gray scaled image
*/
Image* convertToImageGS_YUV(Image* ptrImageRGB){
	//must be an RGB image
	assert(ptrImageRGB->dimension == 3);		
	int i, j;
	Image* ptrImageGS = initImage(ptrImageRGB->width, ptrImageRGB->height, 1);
	unsigned char Y;
	for(i = 0; i < ptrImageGS->height; ++i){
		for(j = 0; j < ptrImageGS->width; ++j){
			//Intensity value
			Y = (unsigned char)((double)getPV(ptrImageRGB, j, i, R) * 0.299 + (double)getPV(ptrImageRGB, j, i, G) * 0.587 + (double)getPV(ptrImageRGB, j, i, B) * 0.114);
			setPV(ptrImageGS, j, i, Y, 0);
		}
	}	
	return ptrImageGS;
}
/*
Converts an Image struct to a Gray Scale struct Image (OpenCV), using the YCbCr format
@param Image*, pointer to the new  image
@return ptrImageGS, pointer to the Gray scaled image
*/
Image* convertToImageGS_YCbCr(Image* ptrImageRGB){
	//must be a RGB image
	assert(ptrImageRGB->dimension == 3);		
	int i, j;
	Image* ptrImageGS = initImage(ptrImageRGB->width, ptrImageRGB->height, 1);
	unsigned char Y;
	for(i = 0; i < ptrImageGS->height; ++i){
		for(j = 0; j < ptrImageGS->width; ++j){
			//Intensity value
			Y = (unsigned char)((double)getPV(ptrImageRGB, j, i, R) * 0.257 + (double)getPV(ptrImageRGB, j, i, G) * 0.504 + (double)getPV(ptrImageRGB, j, i, B) * 0.098) + 16;
			setPV(ptrImageGS, j, i, Y, 0);
		}
	}	
	return ptrImageGS;
}
/*
Saves an Image struct to file
@param ptrPath, absolute or relative path
*/
void saveImageToFile(char* ptrPath, Image* ptrImage){
	IplImage* ptrCvImage = convertToCvImage(ptrImage);
	cvSaveImage(ptrPath, ptrCvImage);
}

/*
*Validates the given image coordinates on the given image
*@param x, x coordinate
*@param y, y coordinate
*@param Image, Image to validate
*@return true, if valid
*/
bool isValid(int x, int y, Image* ptrImage){
	bool valid = false;
	if(x >= 0 && x < ptrImage->width && y >= 0 && y < ptrImage->height)
		valid = true;
	return valid;
}
/*
*Returns the trasposed image
*@param ptrInput, input image
*@return image, trasposed image
*/
Image* trasposeImage(Image* ptrInput){
	Image* ptrOutput = initImage(ptrInput->width, ptrInput->height, 1);
	int x, y;
	for(x = 0; x < ptrInput->width; ++x){
		for( y = 0; y < ptrInput->height; ++y){
			double value = getPV(ptrInput, x, y, 0);
			setPV(ptrOutput, y, x, value, 0);
		}
	}
	return ptrOutput;
}
/*
*Inits an array of doubles
*@param size, size of the array
*@return ArrayDouble, returns the array of doubles
*/
ArrayDouble* initArrayDouble(int size){
	ArrayDouble* ptrArray = (ArrayDouble*)malloc(sizeof(ArrayDouble));
	ptrArray->ptrArray = (double*)malloc(sizeof(double) * size);
	ptrArray->size = size;
	int i;
	for(i = 0; i < size; ++i){
		ptrArray->ptrArray[i] = 0;
	}
	return ptrArray;
}
/*
*Inits an array of integers
*@param size, size of the array
*@return ArrayInt, returns the array of doubles
*/
ArrayInt* initArrayInt(int size){
	ArrayInt* ptrArray = (ArrayInt*)malloc(sizeof(ArrayInt));
	ptrArray->ptrArray = (int*)malloc(sizeof(int) * size);
	ptrArray->size = size;
	int i;
	for(i = 0; i < size; ++i){
		ptrArray->ptrArray[i] = 0;
	}
	return ptrArray;
}
/*
*Deletes an array of integers
*@param ArrayInt, array of integers to delete
*/
void deleteArrayInt(ArrayInt* ptrArray){
	free(ptrArray->ptrArray);
	free(ptrArray);
}
/*
*Deletes an array of doubles
*@param ArrayInt, array of integers to delete
*/
void deleteArrayDouble(ArrayDouble* ptrArray){
	free(ptrArray->ptrArray);
	free(ptrArray);
}



/*
*Adds to images 
*@param ptrA, first operator
*@param ptrB, second operator
*@return result
*/
Image* addImages(Image* ptrA, Image* ptrB){
	assert(ptrA->totalLength == ptrB->totalLength);
	Image* ptrResult = initImage(ptrA->width, ptrA->height, 1);
	int i;
	for(i = 0;i < ptrResult->totalLength; ++i){
		ptrResult->ptrImageData[i] = ptrA->ptrImageData[i] + ptrB->ptrImageData[i];
	}
	return ptrResult;
}



/*
*Inverts the image values making a substraction with the maxValue received (255 on unsigned char)
*@param ptrInput, input image
*@param maxValue, value to be substracted
*@return Image, complemented image
*/
Image* invertImageValues(Image* ptrInput, double maxValue){
	int i;
	Image* ptrOutput = initImage(ptrInput->width, ptrInput->height, 1);
	for(i = 0; i < ptrInput->totalLength; ++i){
		double value = maxValue - ptrInput->ptrImageData[i];
		ptrOutput->ptrImageData[i] = value;
	}
	return ptrOutput;
}
/*
*Inits an Image that is going to be used as a mask
*@param width, mask width
*@param height, mask height
*@param maskFactor, Factor to be applied in the mask convolution
*@return Image, the mask
*/
Image* initMask(int width, int height, double defValue){
	Image* ptrMask = initImage(width, height, 1);
	
	int i = 0;
	for(i = 0; i < ptrMask->totalLength; ++i){
		ptrMask->ptrImageData[i] = defValue;
	}
	return ptrMask;
}

/*
Inits and allocates an image
@param width, Image width
@param height, Image height
@return Image*, pointer to the new image
*/
Image* initImage(int width, int height, int dimension){
	Image* ptrImage = NULL;
	ptrImage = (Image*)malloc(sizeof(Image));
	ptrImage->width = width;
	ptrImage->dimension = dimension;
	ptrImage->height = height;
	ptrImage->totalLength = ((ptrImage->width) * (ptrImage->height) * dimension);
	ptrImage->ptrImageData = (double*)malloc(sizeof(double)*(unsigned int)ptrImage->totalLength);
	
	int i;
	for(i = 0; i < ptrImage->totalLength; ++i){
		ptrImage->ptrImageData[i] = 0;
	}
	return ptrImage;
}

/*
*Frees the memory of an image struct
*@param ptrImage, Image to delete
*@param ptrName, file name
*/
void writeArrayToFile(ArrayInt* ptrArray, const char* ptrName){
	FILE *ptrFile;
	int i;
	ptrFile = fopen(ptrName, "w");
	assert(ptrFile != NULL);
	for (i = 0; i < ptrArray->size; ++i){
		fprintf(ptrFile, "%d;%d\n", i, ptrArray->ptrArray[i]);
	}
	fclose(ptrFile);
}
/*
*Frees the memory of an image struct
*@param ptrImage, Image to delete
*@param ptrName, file name
*/
void writeArrayToFile(ArrayDouble* ptrArray, const char* ptrName){
	FILE *ptrFile;
	int i;
	ptrFile = fopen(ptrName, "w");
	assert(ptrFile != NULL);
	//double sum = 0;
	for (i = 0; i < ptrArray->size; ++i){
		fprintf(ptrFile, "%d;%lf\n", i, ptrArray->ptrArray[i]);
	//	sum += ptrArray->ptrArray[i];
	}
	//printf("LA SUMATORIA ES: %f \n", sum);
	fclose(ptrFile);
}
/*
*Frees the memory of an image struct
*@param ptrImage, Image to delete
*@param ptrName, file name
*/
void deleteImage(Image* ptrImage){
	free(ptrImage->ptrImageData);
	free(ptrImage);
}
/*
Set pixel value on image
Origin: Inferior left pixel
@param ptrImage, RGB image to modify
@param x, x position
@param y, y position
@param layer, if no layer is specified, 0 is assumed
@param value, value to set in the given position
*/
void setPV(Image* ptrImage, int x, int y, double value, int layer){
	assert(x < ptrImage->width && y < ptrImage->height);
	//translation to default axis settings			
	int cy = (ptrImage->height - 1) - y;		
	ptrImage->ptrImageData[ cy * ptrImage->width * ptrImage->dimension + x * ptrImage->dimension + layer] = value;	
}
/*
gets pixel value on RGB image
Origin: Inferior left pixel
@param ptrImage, RGB image to modify
@param x, x position
@param y, y position
@param layer, if no layer is specified, 0 is assumed
@return value, value to set in the given position
*/
double getPV(Image* ptrImage, int x, int y, int layer){
	double value = 0;
	assert(x < ptrImage->width && y < ptrImage->height);		
	//translation to default axis origin			
	int cy = (ptrImage->height - 1) - y;		
	value = ptrImage->ptrImageData[ cy * ptrImage->width * ptrImage->dimension + x * ptrImage->dimension + layer];	
	return value;
}
/*
Set pixel value on Ipl image
Origin: Inferior left pixel
@param ptrImage, Ipl image to modify
@param x, x position
@param y, y position
@param layer, layer
@param value, value to set in the given position
*/
void setPV(IplImage* ptrCvImage, int x, int y, unsigned char value, int layer){
	int cy = (ptrCvImage->height - 1) - y;		
	unsigned char* ptrRowCv = (unsigned char *)(ptrCvImage->imageData + cy * ptrCvImage->widthStep);
	//translation to default axis origin	
	ptrRowCv[ptrCvImage->nChannels * x + layer] = value;		
	
}
/*
gets pixel value on GS image
Origin: Inferior left pixel
@param ptrImage, GS image to modify
@param x, x position
@param y, y position
@return value, value to set in the given position
*/
unsigned char getPV(IplImage* ptrCvImage, int x, int y, int layer){
	unsigned char value = 0;	
	int cy = (ptrCvImage->height - 1) - y;		
	unsigned char* ptrRowCv = (unsigned char *)(ptrCvImage->imageData + cy * ptrCvImage->widthStep);
	//translation to default axis origin				
	value = ptrRowCv[ptrCvImage->nChannels * x + layer];
	return value;
}
