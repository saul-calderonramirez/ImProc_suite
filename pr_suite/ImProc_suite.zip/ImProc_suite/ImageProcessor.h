#pragma once
#define MAX_GS 255
#define MIN_GS 0
#include "stdafx.h"
/*
*Creates a new image with the same size of the mask, copying the surrounding pixels of Xo and Yo
*Calculates the image with the received mask, applying a dot product.
*It also calculates the ponderated the local value of the convolution using the mask and its maskFactor
*Desinged for internal use 
*@param ptrMask, mask to use
*@param ptrInput, Input image
*@param Xo, X coordinate position of the ptrInput pixel 
*@param Yo, Y coordinate position of the ptrInput pixel 
*@param ptrSum, result of multiplying the pixel of the mask with the pixel of the image and the maskFactor
*@return Image, masked image
*/
Image* createMaskedSubImage(Image* ptrMask, Image* ptrInput, int Xo, int Yo, double *ptrSum, bool returnMasked);
/*
*Generates the mask (matrix of 1's) used on the local mean calculation
*@param apertureSize, window size, must be uneven
*@return Image, mean mask
*/
Image* generateMeanMask(int apertureSize);

/*
*Generates the prewitt mask to approximate the X gradient
*@param apertureSize, window size, must be uneven
*@return Image, prewitt mask
*/
Image* generatePrewittXMask(int apertureSize);
/*
*Generates the sobel mask to approximate the X gradient
*@return Image, sobel mask
*/
Image* generateSobelXMask();
/*
*Applies a binary threshold 
*@param ptrInput, input image
*@param threshValue, if the pixel value is higher than threshValue, a 255 (white) is set, 0 is set otherwise
*@return Image, thresholded image
*/
Image* applyThresholdBinary(Image* ptrInput, double threshValue);

/*
*Applies a local mean filter to the image
*@param ptrImage, input image 
*@param apertureSize, window size, must be uneven
*/
Image* filterMean(Image* ptrImage, int apertureSize);

/*
*Applies a variance filter to the image
*@param ptrImage, input image 
*@param apertureSize, window size, must be uneven
*/
Image* filterVariance(Image* ptrImage, int apertureSize);
/*
*Applies a local mean filter to the image
*@param ptrImage, input image 
*@param apertureSize, window size, must be uneven
*/
Image* filterPrewitt(Image* ptrImage, Gradient gradient, int apertureSize);

/*
*Applies a local mean filter to the image
*@param ptrImage, input image 
*@param apertureSize, window size, must be uneven
*/
Image* filterSobel(Image* ptrImage, Gradient gradient);
/*
*Convolves the input image with the mask
*@param ptrInput, input image
*@param ptrMask, mask
*/
Image* filter2D(Image* ptrInput, Image* ptrMask);
/*
*Calculates the image histogram
*@param image, input image must be gray scaled
*@return ArrayInt
*/
ArrayInt* calculateImageHistogram(Image* ptrImageGS);
/*
*Calculates the density function
*@param image, input image must be gray scaled
*@return ArrayDouble
*/
ArrayDouble* calculateImageDensityFunction(Image* ptrImageGS);
/*
*Upsizes the received image by a given factor
*the algorithm uses bilineal interpolation
*@param Image*, pointer to the gray scaled image
*@param factor, resize factor
*@return Image*, pointer to the resized image
*/
Image* upsize(Image* ptrOriginal, int factor);
int* calculateImageHistogramInt(Image* ptrImageGS);
