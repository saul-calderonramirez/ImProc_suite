#include "imageimpro.h"

ImageImPro::ImageImPro()
{
}



