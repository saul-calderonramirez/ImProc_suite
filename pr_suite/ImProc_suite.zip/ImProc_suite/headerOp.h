#ifndef DEFINES_H
#define DEFINES_H
#include "openimprolib_opencvimpl.h"
#include "imageimpro_opencvimpl.h"
#include "highgui.h"
#include "cv.h"
#include <QMainWindow>
#include <iostream>
#include "imageimpro.h"
#include <QMainWindow>
#include "controller.h"
#include "ui_mainwindow.h"
#include "highgui.h"
#include "cv.h"
#include "imageimpro_opencvimpl.h"
#include "openimprolib.h"
#endif // DEFINES_H
using namespace std;
