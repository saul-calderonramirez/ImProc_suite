#pragma once
#define R 0
#define G 1
#define B 2
#define NUM_GRAY_VALUES 256

#include "stdafx.h"

typedef enum {GRAD_X, GRAD_Y, GRAD_X_Y} Gradient;
/*
Image structure
*/
typedef struct Image{
	/*Image dimension or number of layers*/
	int dimension;
	/*Image width*/
	int width;  
	/*Image height*/
	int height; 
	/*Total number of pixels*/
	int totalLength;
	/*Image matrix*/
	double *ptrImageData; 
	
}Image;
/*
*Array of integers
*/
typedef struct ArrayInt{
	/*Array of integers*/
	int* ptrArray;
	/*Array size*/
	int size;
}ArrayInt;
/*
*Array of doubles
*/
typedef struct ArrayDouble{
	/*Array of doubles*/
	double* ptrArray;
	/*Size of the array*/
	int size;
}ArrayDouble;

/*
*Inverts the image values making a substraction with the maxValue received (255 on unsigned char)
*@param ptrInput, input image
*@param maxValue, value to be substracted
*@return Image, complemented image
*/
Image* invertImageValues(Image* ptrInput, double maxValue);

/*
*Returns the trasposed image
*@param ptrInput, input image
*@return image, trasposed image
*/
Image* trasposeImage(Image* ptrInput);
/*
*Adds to images 
*@param ptrA, first operator
*@param ptrB, second operator
*@return result
*/
Image* addImages(Image* ptrA, Image* ptrB);

/*
*Inits an array of doubles
*@param size, size of the array
*@return ArrayDouble, returns the array of doubles
*/
ArrayDouble* initArrayDouble(int size);
/*
*Inits an array of integers
*@param size, size of the array
*@return ArrayInt, returns the array of doubles
*/
ArrayInt* initArrayInt(int size);
/*
*Deletes an array of integers
*@param ArrayInt, array of integers to delete
*/
void deleteArrayInt(ArrayInt* ptrArray);
/*
*Deletes an array of doubles
*@param ArrayInt, array of integers to delete
*/
void deleteArrayDouble(ArrayDouble* ptrArray);

/*
*Inits an Image that is going to be used as a mask
*@param width, mask width
*@param height, mask height
*@param maskFactor, Factor to be applied in the mask convolution
*@return Image, the mask
*/
Image* initMask(int width, int height, double defValue);

/*
*Shows image values on the console
*@param ptrImage, image to show
*/
void printImage(Image* ptrImage);

/*
*Writes the given array to file
*@param ptrImage, array to print
*@param ptrName, file name
*/
void writeArrayToFile(ArrayInt* ptrArray, const char* ptrName);
/*
*Writes the given array to file
*@param ptrArray, Array to print
*/
void writeArrayToFile(ArrayDouble* ptrArray, const char* ptrName);
/*
*Frees the memory of an image struct
*@param ptrImage, Image to delete
*@param ptrName, file name
*/
void deleteImage(Image* ptrImage);
/*
*Inits and allocates a RGB image
*@param width, Image width
*@param height, Image height
*@return Image*, pointer to the new RGB image
*/
Image* initImage(int width, int height, int dimension);

/*
*Converts an IplImage struct Image (OpenCV), to the Image struct
*@param ptrCVImage, pointer to the OpenCV image
*@return Image*, pointer to the new RGB image
*/
Image* convertToImage(IplImage* ptrCvImage);
/*
*Converts an Image struct to IplImage struct Image (OpenCV)
*@param ptrCVImage, pointer to the OpenCV image
*@return Image*, pointer to the new RGB image
*/
IplImage* convertToCvImage(Image* ptrImage);

/*
*Converts an Image struct to a Gray Scale struct Image (OpenCV), using the YUV format
*@param Image*, pointer to the new RGB image
*@return ptrImage, pointer to the Gray scaled image
*/
Image* convertToImageGS_YUV(Image* ptrImageRGB);
/*
*Converts an Image struct to a Gray Scale struct Image (OpenCV), using the YCbCr format
*@param Image*, pointer to the new RGB image
*@return ptrImage, pointer to the Gray scaled image
*/
Image* convertToImageGS_YCbCr(Image* ptrImageRGB);
/*
*Loads an Image struct from file
*@param ptrPath, absolute or relative path
*@return ptrImageRGB, pointer to the RGB image
*/
Image* loadImageC(char* ptrPath);
/*
*Saves an Image struct to file
*@param ptrPath, absolute or relative path
*/
void saveImageToFile(char* ptrPath, Image* ptrImage);
/*
*Calculates the average pixel value of a given Gray Scale Image
*@param Image*, pointer to the gray scaled image
*/
double getMeanPixel(Image* ptrImage);
/*
*Calculates the average pixel value of a given Gray Scale Image
*@param Image*, pointer to the gray scaled image
*/
double getSquaredMeanPixel(Image* ptrImage);

/*
*Calculates the average pixel value of a given Gray Scale Image
*@param Image*, pointer to the gray scaled image
*/
double getVariancePixel(Image* ptrImage);

/*
*sets pixel value on a RGB Scale Image
*Origin: Inferior left pixel
*@param ptrImage, RGB scale image 
*@param x, x position
*@param y, y position
*@param pixel value
*/
void setPV(Image* ptrImage, int x, int y, double value, int layer);
/*
*gets pixel value on a RGB Image
*Origin: Inferior left pixel
*@param ptrImage, RGB image 
*@param x, x position
*@param y, y position
*@return pixel value
*/
double getPV(Image* ptrImage, int x, int y, int layer = 0);
/*
*sets pixel value on a IplImage Image
*Origin: Inferior left pixel
*@param ptrImage, IplImage image 
*@param x, x position
*@param y, y position
*@param value, pixel value
*/
void setPV(IplImage* ptrImage, int x, int y, unsigned char value, int layer);
/*
*gets pixel value on a IplImage Image
*Origin: Inferior left pixel
*@param ptrImage, IplImage image 
*@param x, x position
*@param y, y position
*@return value, pixel value
*/
unsigned char getPV(IplImage* ptrImage, int x, int y, int layer);
/*
*Validates the given image coordinates on the given image
*@param x, x coordinate
*@param y, y coordinate
*@param Image, Image to validate
*@return true, if valid
*/
bool isValid(int x, int y, Image* ptrImage);
